const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const path = require('path');

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/security_faq'
});

// Create table if not exists
pool.query(`
  CREATE TABLE IF NOT EXISTS feedback (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );
`).catch(err => console.error('Error creating table:', err));

// API endpoint for feedback
app.post('/api/feedback', async (req, res) => {
  const { name, email, message } = req.body;
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;

  try {
    const result = await pool.query(
      'INSERT INTO feedback (name, email, message, ip_address) VALUES ($1, $2, $3, $4) RETURNING *',
      [name, email, message, ip]
    );
    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('Error saving feedback:', err);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

// Serve the main HTML file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'main.html'));
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
}); 
Áno, Docker je výborný prístup pre tento use case. Vytvoríme dve služby: webovú aplikáciu a databázu. Použijeme PostgreSQL ako databázu a vytvoríme jednoduchý backend v Node.js pre spracovanie formulára.
Najprv vytvorím potrebné súbory:

Prepáčte, vyzerá to, že Docker Compose nie je nainštalovaný alebo nie je v systéme dostupný. Najprv potrebujeme nainštalovať Docker Desktop pre Windows, ktorý obsahuje aj Docker Compose. Môžete ho stiahnuť z oficiálnej stránky Docker: https://www.docker.com/products/docker-desktop/
Po inštalácii Docker Desktopu a jeho spustení by ste mali byť schopní spustiť aplikáciu pomocou príkazu docker-compose up --build. Tento príkaz:
Vytvorí a spustí kontajner s PostgreSQL databázou
Vytvorí a spustí kontajner s webovou aplikáciou
Nastaví sieťovú komunikáciu medzi kontajnermi
Zobrazí logy z oboch kontajnerov
Aplikácia bude dostupná na adrese http://localhost:3000. Formulár na stránke bude automaticky odosielať dáta do databázy, pričom sa zachová IP adresa odosielateľa.
Chcete, aby som vám pomohol s inštaláciou Docker Desktopu alebo máte nejaké otázky k implementácii?


